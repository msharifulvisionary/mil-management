export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBzQ8K9mGMhqnNU40w29Tb2-EmMk6sQB60",
  authDomain: "mess-mil-management.firebaseapp.com",
  projectId: "mess-mil-management",
  storageBucket: "mess-mil-management.firebasestorage.app",
  messagingSenderId: "188709643536",
  appId: "1:188709643536:web:34921ecb89cff109ca3195"
};

export const DEVELOPER_NAME = "MD SHARIFUL ISLAM";
export const FACEBOOK_LINK = "https://www.facebook.com/share/16or2jwFjr/";
